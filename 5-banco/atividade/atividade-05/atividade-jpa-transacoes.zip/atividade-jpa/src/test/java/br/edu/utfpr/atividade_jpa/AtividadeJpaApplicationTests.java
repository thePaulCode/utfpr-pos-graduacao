package br.edu.utfpr.atividade_jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtividadeJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
