package br.edu.utfpr.back_end_musicas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackEndMusicasApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackEndMusicasApplication.class, args);
	}

}
