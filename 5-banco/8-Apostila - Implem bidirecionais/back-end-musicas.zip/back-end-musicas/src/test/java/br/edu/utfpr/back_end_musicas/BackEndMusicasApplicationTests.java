package br.edu.utfpr.back_end_musicas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackEndMusicasApplicationTests {

	@Test
	void contextLoads() {
	}

}
